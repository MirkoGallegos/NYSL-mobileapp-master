var data = {
    games:[
        {date:"9/01",teams:"U1 and U4",location:"AJ Katzenmaier",times:"9:30 a.m."},
        {date:"9/01",teams:"U3 and U2",location:"Greenbay",times:"1:00 p.m."},
        {date:"9/08",teams:"U5 and U6",location:"Howard A Yeager",times:"9:30 a.m."},
        {date:"9/08",teams:"U6 and U1",location:"Marjorie P Hart",times:"1:00 p.m."},
        {date:"9/15",teams:"U2 and U4",location:"North",times:"9:30 a.m."},
        {date:"9/15",teams:"U3 and U5",location:"AJ Katzenmaier",times:"1:00 p.m."},
        {date:"9/22",teams:"U1 and U3",location:"South",times:"9:30 a.m."},
        {date:"9/22",teams:"U2 and U6",location:"Howard A Yeager",times:"1:00 p.m."},
        {date:"9/29",teams:"U4 and U5",location:"Greenbay",times:"9:30 a.m."}        
    ],
    messages:[]
}